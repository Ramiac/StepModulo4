//  ##### Nav collapse function #####

$(document).ready(function () {
    $('.sidenav').sidenav();
})

// ##### Carousel #####

$(document).ready(function(){
    $('.slider').slider({fullWidth: true});
  });

//   ##### Form #####
$('#icon_prefix2').val('');
M.textareaAutoResize($('#icon_prefix2'));
